import { DatabaseSync } from 'node:sqlite';
import { mkdir, readFile, writeFile, rename, rm } from 'node:fs/promises';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash, randomUUID } from 'node:crypto';

const projectRoot = resolve(fileURLToPath(new URL('..', import.meta.url)));

function metadata(result = {}) {
  return { changes: Number(result.changes || 0), last_row_id: Number(result.lastInsertRowid || 0) };
}

class LocalD1Statement {
  constructor(database, sql, values = []) { this.database = database; this.sql = sql; this.values = values; }
  bind(...values) { return new LocalD1Statement(this.database, this.sql, values); }
  async first(column) {
    const row = this.database.sqlite.prepare(this.sql).get(...this.values) || null;
    return column ? row?.[column] ?? null : row;
  }
  async all() {
    const results = this.database.sqlite.prepare(this.sql).all(...this.values);
    return { success: true, results, meta: { changes: 0 } };
  }
  async run() {
    const result = this.database.sqlite.prepare(this.sql).run(...this.values);
    return { success: true, results: [], meta: metadata(result) };
  }
}

class LocalD1 {
  constructor(sqlite) { this.sqlite = sqlite; }
  prepare(sql) { return new LocalD1Statement(this, sql); }
  async batch(statements) {
    this.sqlite.exec('BEGIN IMMEDIATE');
    try {
      const results = statements.map(statement => {
        if (!(statement instanceof LocalD1Statement) || statement.database !== this) throw new Error('Invalid local D1 statement');
        const prepared = this.sqlite.prepare(statement.sql);
        if (prepared.columns().length) return { success: true, results: prepared.all(...statement.values), meta: { changes: 0 } };
        return { success: true, results: [], meta: metadata(prepared.run(...statement.values)) };
      });
      this.sqlite.exec('COMMIT');
      return results;
    } catch (error) {
      this.sqlite.exec('ROLLBACK');
      throw error;
    }
  }
}

async function bytes(value) {
  if (typeof value === 'string') return Buffer.from(value);
  if (value instanceof ArrayBuffer) return Buffer.from(value);
  if (ArrayBuffer.isView(value)) return Buffer.from(value.buffer, value.byteOffset, value.byteLength);
  if (value instanceof Blob) return Buffer.from(await value.arrayBuffer());
  return Buffer.from(await new Response(value).arrayBuffer());
}

class LocalR2 {
  constructor(objectPath) { this.objectPath = objectPath; }
  location(key) { return join(this.objectPath, createHash('sha256').update(String(key)).digest('hex')); }
  async put(key, value, options = {}) {
    const body = await bytes(value);
    const file = this.location(key);
    const temp = file + '.' + randomUUID() + '.tmp';
    const record = { key: String(key), size: body.byteLength, etag: createHash('sha256').update(body).digest('hex'), uploaded: new Date().toISOString(), httpMetadata: options.httpMetadata || {}, customMetadata: options.customMetadata || {} };
    await writeFile(temp, body);
    await rename(temp, file);
    await writeFile(file + '.json', JSON.stringify(record));
    return this.objectResult(record, body);
  }
  objectResult(record, body) {
    return {
      ...record,
      httpEtag: '"' + record.etag + '"',
      uploaded: new Date(record.uploaded),
      body: new Blob([body]),
      async arrayBuffer() { return body.buffer.slice(body.byteOffset, body.byteOffset + body.byteLength); },
      async text() { return body.toString('utf8'); },
      writeHttpMetadata(headers) {
        const names = { contentType: 'Content-Type', contentLanguage: 'Content-Language', contentDisposition: 'Content-Disposition', contentEncoding: 'Content-Encoding', cacheControl: 'Cache-Control' };
        Object.entries(record.httpMetadata).forEach(([key, value]) => { if (names[key] && value != null) headers.set(names[key], String(value)); });
      },
    };
  }
  async get(key) {
    const file = this.location(key);
    try {
      const [body, data] = await Promise.all([readFile(file), readFile(file + '.json', 'utf8')]);
      return this.objectResult(JSON.parse(data), body);
    } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
  }
  async delete(key) {
    const keys = Array.isArray(key) ? key : [key];
    await Promise.all(keys.flatMap(item => [rm(this.location(item), { force: true }), rm(this.location(item) + '.json', { force: true })]));
  }
}

/** A disk-backed local emulator only. It is never part of the hosted Worker. */
export async function createLocalEnv({ databasePath = ':memory:', objectPath, ownerEmail = 'local-dev@example.test' } = {}) {
  if (!objectPath) throw new Error('Provide an explicit local objectPath');
  if (databasePath !== ':memory:') await mkdir(dirname(resolve(databasePath)), { recursive: true });
  await mkdir(resolve(objectPath), { recursive: true });
  const sqlite = new DatabaseSync(databasePath);
  sqlite.exec('PRAGMA foreign_keys = ON');
  sqlite.exec('CREATE TABLE IF NOT EXISTS _local_migrations (name TEXT PRIMARY KEY)');
  const migration = '0000_shared_album.sql';
  const applied = sqlite.prepare('SELECT name FROM _local_migrations WHERE name = ?').get(migration);
  try {
    if (!applied) {
      const sql = await readFile(join(projectRoot, 'drizzle', migration), 'utf8');
      sqlite.exec('BEGIN IMMEDIATE');
      try { sqlite.exec(sql); sqlite.prepare('INSERT INTO _local_migrations (name) VALUES (?)').run(migration); sqlite.exec('COMMIT'); }
      catch (error) { sqlite.exec('ROLLBACK'); throw error; }
    }
    return { DB: new LocalD1(sqlite), BUCKET: new LocalR2(resolve(objectPath)), OWNER_EMAIL: ownerEmail, close() { sqlite.close(); } };
  } catch (error) { sqlite.close(); throw error; }
}

