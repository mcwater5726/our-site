(() => {
  'use strict';

  const KEY = 'tutu-love-diary-v1';
  const DB_NAME = 'tutu-love-photos-v1';
  const CITIES = ['泉州', '青岛', '苏州', '厦门', '连云港', '南京', '镇江', '扬州'];
  const $ = (selector, scope = document) => scope.querySelector(selector);
  const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];
  const uid = () => globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const today = () => new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
  const prettyDate = (date) => date.replaceAll('-', '.');
  const validDate = (date) => typeof date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(date) && !Number.isNaN(Date.parse(`${date}T00:00:00Z`)) && new Date(`${date}T00:00:00Z`).toISOString().slice(0, 10) === date;
  const plain = (value, max = 100) => String(value ?? '').trim().slice(0, max);
  const defaults = () => ({
    profile: { girl: '朱迪', boy: '1150', metDate: '2026-06-14', place: '玄武湖' },
    memories: [{ id: 'first-meeting', title: '初遇，在玄武湖', date: '2026-06-14', description: '在玄武湖听音乐时，我们认识了。那一天，故事开始有了我们。' }],
    wishes: ['一起再去玄武湖听音乐', '拍一张只属于我们的合照', '找一家好吃的小店', '一起看一场日落'].map(text => ({ id: uid(), text, done: false })),
    letter: null,
    letterDate: null,
  });

  let state = defaults();
  let photos = [];
  let filter = 'all';
  let cityFilter = '';
  let pendingPhotos = [];
  let lightboxItems = [];
  let lightboxIndex = 0;
  let toastTimer;
  let dbPromise;
  let musicContext;
  let musicTimer;
  let musicBusy = false;
  let localState = defaults();
  let localPhotos = [];
  let session = { canEdit: false, authenticated: false, loginUrl: '/signin-with-chatgpt?return_to=%2F' };
  let cloudReady = false;
  let cloudLoading = false;
  let cloudError = '';
  let cloudConflict = false;
  let revision = 0;
  let writeBusy = false;
  let preparingUpload = false;
  let initialLetter = '';

  function toast(message) {
    const node = $('#toast');
    if (!node) return;
    clearTimeout(toastTimer);
    node.textContent = message;
    node.classList.add('show', 'is-visible');
    node.hidden = false;
    toastTimer = setTimeout(() => {
      node.classList.remove('show', 'is-visible');
      node.hidden = true;
    }, 4300);
  }

  function mirrorState(value) {
    try {
      localStorage.setItem(KEY, JSON.stringify(value));
    } catch { /* Cloud data is authoritative; this is a best-effort local backup. */ }
  }

  const clone = value => JSON.parse(JSON.stringify(value));

  async function api(path, options = {}, mode = 'json') {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);
    const method = options.method || 'GET';
    try {
      const response = await fetch(path, {
        method,
        credentials: 'same-origin',
        cache: 'no-store',
        signal: controller.signal,
        headers: method === 'GET' ? {} : { 'Content-Type': 'application/json' },
        ...(options.body === undefined ? {} : { body: JSON.stringify(options.body) }),
      });
      if (!response.ok) {
        let message = '';
        try { message = (await response.json()).error; } catch { /* The server may return an HTML error page. */ }
        const error = new Error(typeof message === 'string' && message ? message : response.status === 409 ? '手账已有新的修改，请先刷新，再重新保存。' : response.status === 401 || response.status === 403 ? '请用小窝主人的账号登录后再编辑。' : '云端暂时没有回应，请稍后重试。');
        error.status = response.status;
        throw error;
      }
      return mode === 'blob' ? await response.blob() : await response.json();
    } catch (error) {
      if (error.name === 'AbortError') throw new Error('连接云端超时了，请检查网络后重试。');
      if (error instanceof TypeError) throw new Error('暂时连接不上云端，请检查网络后重试。');
      if (error instanceof SyntaxError) throw new Error('云端暂时返回了无法读取的内容，请刷新后重试。');
      throw error;
    } finally { clearTimeout(timeout); }
  }

  function ownerAllowed() { return session.canEdit && cloudReady && !cloudConflict; }

  function requireOwner() {
    if (!session.canEdit) { toast('这里由小窝主人编辑，登录主人账号后就可以收藏回忆。'); return false; }
    if (!cloudReady || cloudConflict) { toast(cloudConflict ? '手账已有新修改，请先刷新云端内容。' : '请先成功加载云端内容，再进行修改。'); return false; }
    return true;
  }

  function updateCloudUI() {
    $$('[data-owner-only]').forEach(node => { node.hidden = !session.canEdit || !cloudReady; });
    if ($('#wish-form')) $('#wish-form').hidden = !session.canEdit || !cloudReady;
    $$('[data-owner-only] button, [data-owner-only] input, [data-owner-only] select, [data-owner-only] textarea, button[data-owner-only], input[data-owner-only]').forEach(node => { node.disabled = writeBusy || cloudLoading || !ownerAllowed(); });
    $$('#settings-form input, #settings-form button, #upload-form input, #upload-form select, #upload-form button, #memory-form input, #memory-form textarea, #memory-form button, #letter-form textarea, #letter-form button, #migration-form input, #migration-form button, #wish-form input, #wish-form button').forEach(node => { node.disabled = writeBusy || !ownerAllowed(); });
    ['#export-data', '#import-data', '#select-all-local', '#photo-delete'].forEach(selector => { if ($(selector)) $(selector).disabled = writeBusy || !ownerAllowed(); });
    $$('[data-upload]').forEach(button => { button.disabled = writeBusy || preparingUpload || !ownerAllowed(); });
    $$('#wish-list input').forEach(input => { input.disabled = writeBusy || !ownerAllowed(); });
    if ($('#cloud-status')) {
      $('#cloud-status').textContent = cloudLoading ? '正在连接云端…' : cloudConflict ? '有新修改，请刷新' : cloudError ? '云端连接需要重试' : cloudReady ? '照片与手账已云端共享' : '云端尚未连接';
      $('#cloud-status').dataset.state = cloudError || cloudConflict ? 'error' : cloudReady ? 'ready' : 'loading';
      $('#cloud-status').closest('.cloud-banner')?.classList.toggle('error', Boolean(cloudError || cloudConflict));
    }
    if ($('#owner-login')) {
      $('#owner-login').hidden = session.canEdit;
      $('#owner-login').href = session.loginUrl;
      $('#owner-login').textContent = session.authenticated ? '切换主人账号' : '主人登录';
    }
    if ($('#cloud-refresh')) $('#cloud-refresh').disabled = cloudLoading || writeBusy;
    if ($('#local-photo-count')) $('#local-photo-count').textContent = `这个浏览器还保留着 ${localPhotos.length} 张本机照片。它们不会自动公开，勾选后才会同步。`;
    if ($('#sync-local-photos')) $('#sync-local-photos').disabled = !ownerAllowed() || writeBusy || !localPhotos.length;
    if ($('#photo-delete')) $('#photo-delete').hidden = !ownerAllowed() || Boolean(lightboxItems[lightboxIndex]?.sample);
  }

  async function cacheDiary(value) {
    localState = clone(value);
    mirrorState(value);
    try { await writeDiary(value); } catch { /* A local backup failure does not undo a successful cloud write. */ }
  }

  async function saveState(candidate) {
    const snapshot = validateState(candidate);
    if (snapshot.letter === null) snapshot.letter = initialLetter;
    const result = await api('/api/diary', { method: 'PUT', body: { diary: snapshot, revision } });
    if (!Number.isInteger(result.revision)) throw new Error('云端没有返回保存结果，请刷新后确认。');
    revision = result.revision;
    state = snapshot;
    cloudError = '';
    await cacheDiary(snapshot);
    renderAll();
    updateCloudUI();
  }

  async function ownerAction(target, callback) {
    if (!requireOwner() || writeBusy) return false;
    writeBusy = true;
    if (target) target.setAttribute('aria-busy', 'true');
    updateCloudUI();
    try { await callback(); return true; }
    catch (error) {
      if (error.status === 409) cloudConflict = true;
      if (error.status === 401 || error.status === 403) session.canEdit = false;
      cloudError = error.message || '云端同步失败，请稍后重试。';
      toast(cloudError);
      return false;
    } finally {
      writeBusy = false;
      if (target) target.removeAttribute('aria-busy');
      updateCloudUI();
      renderWishes();
    }
  }

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function openDialog(id) {
    const dialog = $(id);
    if (dialog && !dialog.open) dialog.showModal();
  }

  function closeDialog(id) {
    $(id)?.close();
  }

  function database() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      if (!globalThis.indexedDB) return reject(new Error('相册存储不可用'));
      let settled = false;
      const request = indexedDB.open(DB_NAME, 2);
      request.onupgradeneeded = () => {
        if (!request.result.objectStoreNames.contains('photos')) request.result.createObjectStore('photos', { keyPath: 'id' });
        if (!request.result.objectStoreNames.contains('metadata')) request.result.createObjectStore('metadata');
      };
      request.onsuccess = () => {
        if (settled) { request.result.close(); return; }
        settled = true;
        request.result.onversionchange = () => { request.result.close(); dbPromise = undefined; };
        resolve(request.result);
      };
      request.onerror = () => { settled = true; reject(request.error || new Error('无法打开相册')); };
      request.onblocked = () => { settled = true; reject(new Error('请关闭其他打开的小窝页面，再试一次')); };
    });
    return dbPromise;
  }

  async function readPhotos() {
    const db = await database();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('photos', 'readonly');
      const request = tx.objectStore('photos').getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  async function readStoredDiary() {
    const db = await database();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(['photos', 'metadata'], 'readonly');
      const photoRequest = tx.objectStore('photos').getAll();
      const diaryRequest = tx.objectStore('metadata').get('diary');
      tx.oncomplete = () => resolve({ photos: photoRequest.result || [], diary: diaryRequest.result });
      tx.onerror = () => reject(tx.error || new Error('无法读取本机手账'));
      tx.onabort = () => reject(tx.error || new Error('读取本机手账未完成'));
    });
  }

  async function writeDiary(value) {
    const db = await database();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('metadata', 'readwrite');
      tx.objectStore('metadata').put(value, 'diary');
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error || new Error('手账保存失败'));
      tx.onabort = () => reject(tx.error || new Error('手账保存未完成'));
    });
  }

  async function writePhotos(items) {
    const db = await database();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('photos', 'readwrite');
      const store = tx.objectStore('photos');
      try {
        items.forEach(item => store.put(item));
      } catch (error) {
        tx.abort();
        reject(error);
        return;
      }
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error || new Error('照片保存失败'));
      tx.onabort = () => reject(tx.error || new Error('照片保存未完成'));
    });
  }

  function cloudPhoto(photo) {
    if (!photo || typeof photo.id !== 'string' || !/^\/api\/images\/[A-Za-z0-9_-]+$/.test(photo.src) || !validDate(photo.date) || !['us', 'daily', 'travel'].includes(photo.category) || (photo.city && !CITIES.includes(photo.city))) throw new Error('云端照片内容暂时无法读取，请刷新重试。');
    return { id: photo.id, src: photo.src, title: plain(photo.title, 80) || '我们的心动瞬间', date: photo.date, category: photo.category, city: photo.city || '', createdAt: Number.isFinite(photo.createdAt) ? photo.createdAt : 0 };
  }

  function mergeCloudPhoto(photo) {
    const safePhoto = cloudPhoto(photo);
    const index = photos.findIndex(item => item.id === safePhoto.id);
    if (index === -1) photos.push(safePhoto); else photos[index] = safePhoto;
  }

  async function refreshCloud() {
    if (cloudLoading || writeBusy) return;
    cloudLoading = true;
    cloudReady = false;
    cloudError = '';
    cloudConflict = false;
    updateCloudUI();
    renderAlbum();
    try {
      const identity = await api('/api/session');
      session = { canEdit: identity.canEdit === true, authenticated: identity.authenticated === true, loginUrl: typeof identity.loginUrl === 'string' && identity.loginUrl.startsWith('/') && !identity.loginUrl.startsWith('//') ? identity.loginUrl : '/signin-with-chatgpt?return_to=%2F' };
      const [album, diaryResult] = await Promise.all([api('/api/photos'), api('/api/diary')]);
      if (!Array.isArray(album.photos) || !Number.isInteger(diaryResult.revision)) throw new Error('云端内容暂时无法读取，请刷新重试。');
      const nextPhotos = album.photos.map(cloudPhoto);
      revision = diaryResult.revision;
      let nextState = diaryResult.diary === null ? null : validateState(diaryResult.diary);
      if (!nextState && session.canEdit) {
        nextState = clone(localState);
        if (nextState.letter === null) nextState.letter = initialLetter;
        try {
          const result = await api('/api/diary', { method: 'PUT', body: { diary: nextState, revision } });
          if (!Number.isInteger(result.revision)) throw new Error('云端没有返回保存结果，请刷新后确认。');
          revision = result.revision;
        } catch (error) {
          if (error.status !== 409) throw error;
          const latest = await api('/api/diary');
          if (!latest.diary || !Number.isInteger(latest.revision)) throw error;
          nextState = validateState(latest.diary);
          revision = latest.revision;
        }
      }
      state = nextState || defaults();
      if (state.letter === null) state.letter = initialLetter;
      photos = nextPhotos;
      cloudReady = true;
      if (session.canEdit) await cacheDiary(state);
      renderAll();
    } catch (error) {
      cloudError = error.message || '云端加载失败，请点击重新连接。';
      if (error.status === 401 || error.status === 403) session.canEdit = false;
      renderAlbum();
      toast(cloudError);
    } finally {
      cloudLoading = false;
      updateCloudUI();
      renderAlbum();
      renderWishes();
    }
  }

  async function preserveLocalPhotos(items) {
    items.forEach(photo => {
      const index = localPhotos.findIndex(item => item.id === photo.id);
      if (index === -1) localPhotos.push(photo); else localPhotos[index] = photo;
    });
    try { await writePhotos(items); } catch { /* The upload queue still retains the original images for retry. */ }
    updateCloudUI();
  }

  async function uploadBatch(items, onProgress) {
    const successful = [];
    const failed = [];
    const retiredIds = [];
    let lastError = null;
    for (let index = 0; index < items.length; index++) {
      const photo = items[index];
      try {
        const result = await api('/api/photos', { method: 'POST', body: photo });
        mergeCloudPhoto(result.photo);
        successful.push(photo);
      } catch (error) {
        failed.push(photo);
        lastError = error;
        if (error.status === 410) retiredIds.push(photo.id);
        if (error.status === 401 || error.status === 403) {
          failed.push(...items.slice(index + 1));
          session.canEdit = false;
          onProgress?.(successful.length, failed.length, items.length);
          break;
        }
      }
      onProgress?.(successful.length, failed.length, items.length);
      renderAlbum();
    }
    return { successful, failed, lastError, retiredIds };
  }

  function failedUploadHint(result) {
    return result.retiredIds.length ? '有照片已从云端移除；如需重新分享，请重新选择原图作为新照片添加。' : `${result.lastError?.message || '请稍后重试。'} 已有云端照片不会重复添加。`;
  }

  function renderMigrationList(selectedIds) {
    const list = $('#migration-list');
    if (!list) return;
    list.replaceChildren();
    const sharedIds = new Set(photos.map(photo => photo.id));
    localPhotos.forEach(photo => {
      const label = element('label', 'migration-item');
      const input = element('input');
      input.type = 'checkbox';
      input.name = 'localPhotos';
      input.value = photo.id;
      input.checked = selectedIds ? selectedIds.has(photo.id) : true;
      input.disabled = writeBusy;
      input.addEventListener('change', updateLocalSelection);
      const image = element('img');
      image.src = photo.src;
      image.alt = photo.title || '本机照片';
      image.loading = 'lazy';
      const text = element('span', 'migration-caption');
      text.append(element('strong', '', photo.title || '我们的心动瞬间'), element('small', '', `${prettyDate(photo.date)}${photo.city ? ` · ${photo.city}` : ''}${sharedIds.has(photo.id) ? ' · 已在云端' : ''}`));
      label.append(input, image, text);
      list.append(label);
    });
    if (!localPhotos.length) list.append(element('p', '', '这个浏览器没有待同步的本机照片。也可以用回忆备份导入到云端。'));
    updateLocalSelection();
  }

  function updateLocalSelection() {
    const all = $('#select-all-local');
    if (!all || all.type !== 'checkbox') return;
    const inputs = $$('#migration-list input[type="checkbox"]');
    const checked = inputs.filter(input => input.checked).length;
    all.checked = inputs.length > 0 && checked === inputs.length;
    all.indeterminate = checked > 0 && checked < inputs.length;
  }

  function migrationProgress(successful, failed, total) {
    const message = `已成功 ${successful} 张，失败 ${failed} 张，共选择 ${total} 张。`;
    if ($('#migration-status')) $('#migration-status').textContent = message;
    if ($('#local-photo-count')) $('#local-photo-count').textContent = message;
  }

  function renderProfile() {
    $$('[data-girl]').forEach(node => { node.textContent = state.profile.girl; });
    $$('[data-boy]').forEach(node => { node.textContent = state.profile.boy; });
    $$('[data-place]').forEach(node => { node.textContent = state.profile.place; });
    const dayCount = Math.max(0, Math.floor((Date.parse(`${today()}T00:00:00Z`) - Date.parse(`${state.profile.metDate}T00:00:00Z`)) / 86400000));
    if ($('#days-count')) $('#days-count').textContent = String(dayCount);
    if ($('#met-date-label')) $('#met-date-label').textContent = prettyDate(state.profile.metDate);
    if ($('#met-place-label')) $('#met-place-label').textContent = state.profile.place === '玄武湖' ? '南京 · 玄武湖' : state.profile.place;
    const heroDescription = $('.hero-description');
    if (heroDescription?.firstChild?.nodeType === Node.TEXT_NODE) heroDescription.firstChild.textContent = `从${state.profile.place}的那场音乐开始，`;
    document.title = `${state.profile.girl}与${state.profile.boy} · 我们的恋爱手账`;
  }

  const samples = [
    { id: 'sample-picnic', src: 'assets/picnic.svg', title: '想和你，浪费一个下午', date: '回忆插画 · 等待我们的照片', sample: true, category: 'all' },
    { id: 'sample-flower', src: 'assets/flower.svg', title: '普通日子，也要有一点浪漫', date: '回忆插画 · 等待我们的照片', sample: true, category: 'all' },
    { id: 'sample-moon', src: 'assets/moon.svg', title: '晚风和月亮，还有你', date: '回忆插画 · 等待我们的照片', sample: true, category: 'all' },
  ];

  function shownPhotos() {
    return photos.filter(photo => (filter === 'all' || photo.category === filter) && (!cityFilter || photo.city === cityFilter)).sort((a, b) => b.date.localeCompare(a.date) || (b.createdAt || 0) - (a.createdAt || 0));
  }

  function renderAlbum() {
    const grid = $('#album-grid');
    if (!grid) return;
    grid.replaceChildren();
    if (!cloudReady) {
      if ($('#photo-count')) $('#photo-count').textContent = cloudLoading ? '正在读取云端相册…' : '云端相册尚未连接';
      if ($('#album-empty-note')) $('#album-empty-note').hidden = true;
      const message = element('div', 'album-no-results cloud-empty-state');
      message.append(element('span', '', '♡'), element('p', '', cloudLoading ? '正在把云端的心动瞬间带回来…' : cloudError || '先连接云端，就能看到共享的照片。'));
      if (!cloudLoading) {
        const retry = element('button', 'button secondary', '重新连接云端');
        retry.type = 'button';
        retry.addEventListener('click', refreshCloud);
        message.append(retry);
      }
      grid.append(message);
      return;
    }
    if ($('#photo-count')) $('#photo-count').textContent = photos.length ? `共 ${photos.length} 张心动照片` : '等待第一张合照';
    if ($('#album-empty-note')) $('#album-empty-note').hidden = photos.length > 0 || filter !== 'all' || Boolean(cityFilter);
    if ($('#city-album-state')) $('#city-album-state').hidden = !cityFilter;
    if ($('#city-album-label')) $('#city-album-label').textContent = cityFilter ? `${cityFilter}的旅行回忆` : '';
    $$('[data-city]').forEach(button => {
      const active = button.dataset.city === cityFilter;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    const items = !photos.length && filter === 'all' ? samples : shownPhotos();
    if (!items.length) {
      const empty = element('div', 'album-no-results');
      empty.append(element('span', '', '♡'), element('p', '', cityFilter ? `${cityFilter}的旅行照片还没有住进来，把一起走过的风景收藏在这里吧。` : '这里还没有照片，来收藏一个心动瞬间吧。'));
      if (ownerAllowed()) {
        const button = element('button', 'button primary', '添加照片');
        button.type = 'button';
        button.disabled = writeBusy;
        button.addEventListener('click', () => { if (requireOwner() && !writeBusy) $('#photo-input')?.click(); });
        empty.append(button);
      }
      grid.append(empty);
    }
    items.forEach((photo, index) => {
      const card = element('article', `photo-card${photo.sample ? ' sample-card' : ''}`);
      const button = element('button', 'photo-open');
      button.type = 'button';
      button.setAttribute('aria-label', `查看${photo.sample ? '插画' : '照片'}：${photo.title}`);
      const image = element('img');
      image.src = photo.src;
      image.alt = photo.title;
      image.loading = 'lazy';
      image.decoding = 'async';
      button.append(image);
      const caption = element('div', 'photo-caption');
      caption.append(element('h3', '', photo.title), element('p', '', photo.sample ? photo.date : `${prettyDate(photo.date)}${photo.city ? ` · ${photo.city}` : ''}`));
      button.append(caption);
      if (photo.sample) button.append(element('span', 'sample-label', '回忆插画'));
      button.addEventListener('click', () => {
        lightboxItems = items;
        lightboxIndex = index;
        renderLightbox();
        openDialog('#lightbox-dialog');
      });
      card.append(button);
      grid.append(card);
    });
    $$('#album-filters [data-filter]').forEach(button => {
      const active = button.dataset.filter === filter;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
  }

  function renderLightbox() {
    const photo = lightboxItems[lightboxIndex];
    if (!photo) return;
    const image = $('#lightbox-img');
    if (image) { image.src = photo.src; image.alt = photo.title; }
    if ($('#lightbox-title')) $('#lightbox-title').textContent = photo.title;
    if ($('#lightbox-date')) $('#lightbox-date').textContent = photo.sample ? photo.date : `${prettyDate(photo.date)}${photo.city ? ` · ${photo.city}` : ''}`;
    if ($('#lightbox-counter')) $('#lightbox-counter').textContent = `${lightboxIndex + 1} / ${lightboxItems.length}`;
    if ($('#photo-delete')) $('#photo-delete').hidden = !ownerAllowed() || Boolean(photo.sample);
    $$('[data-photo-prev], [data-photo-next]').forEach(button => { button.disabled = lightboxItems.length < 2; });
  }

  function navigatePhoto(direction) {
    if (!lightboxItems.length) return;
    lightboxIndex = (lightboxIndex + direction + lightboxItems.length) % lightboxItems.length;
    renderLightbox();
  }

  function renderMemories() {
    const list = $('#memories-list');
    if (!list) return;
    list.replaceChildren();
    [...state.memories].sort((a, b) => a.date.localeCompare(b.date)).forEach(memory => {
      const item = element('article', 'memory-item');
      const content = element('div', 'memory-content');
      const time = element('time', '', prettyDate(memory.date));
      time.dateTime = memory.date;
      content.append(time, element('h3', '', memory.title), element('p', '', memory.description));
      item.append(element('span', 'memory-dot'), content);
      list.append(item);
    });
  }

  function renderWishes() {
    const list = $('#wish-list');
    if (!list) return;
    list.replaceChildren();
    state.wishes.forEach(wish => {
      const label = element('label', `wish-item${wish.done ? ' is-done' : ''}`);
      const input = element('input');
      input.type = 'checkbox';
      input.checked = wish.done;
      input.disabled = !ownerAllowed() || writeBusy;
      input.addEventListener('change', async () => {
        const checked = input.checked;
        await ownerAction(input, async () => {
          const candidate = clone(state);
          const currentWish = candidate.wishes.find(item => item.id === wish.id);
          if (!currentWish) return;
          currentWish.done = checked;
          await saveState(candidate);
          if (checked) toast('又完成一件属于我们的可爱小事 ♡');
        });
        renderWishes();
      });
      const check = element('span', 'wish-check');
      check.setAttribute('aria-hidden', 'true');
      label.append(input, check, element('span', 'wish-label', wish.text));
      list.append(label);
    });
    if ($('#wish-progress')) $('#wish-progress').textContent = `已完成 ${state.wishes.filter(wish => wish.done).length} / ${state.wishes.length}`;
  }

  function renderLetter() {
    if (state.letter !== null && $('#letter-text')) $('#letter-text').textContent = state.letter;
    if ($('#letter-date')) $('#letter-date').textContent = state.letterDate ? `最后修改于 ${prettyDate(state.letterDate)}` : `写给我的${state.profile.girl}`;
  }

  function renderAll() {
    renderProfile();
    renderAlbum();
    renderMemories();
    renderWishes();
    renderLetter();
    updateCloudUI();
  }

  function formValue(form, name, max) { return plain(form.elements.namedItem(name)?.value, max); }

  async function compressPhoto(file) {
    if (!file.type.startsWith('image/')) throw new Error('请选择图片文件');
    if (file.size > 30 * 1024 * 1024) throw new Error('单张图片请小于 30 MB');
    const url = URL.createObjectURL(file);
    try {
      const image = new Image();
      image.src = url;
      await image.decode();
      if (!image.naturalWidth || !image.naturalHeight) throw new Error('这张图片暂时无法读取，请换成 JPG、PNG 或 WebP');
      const ratio = Math.min(1, 1600 / Math.max(image.naturalWidth, image.naturalHeight));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(image.naturalWidth * ratio));
      canvas.height = Math.max(1, Math.round(image.naturalHeight * ratio));
      const context = canvas.getContext('2d');
      if (!context) throw new Error('浏览器暂时无法处理照片');
      context.fillStyle = '#fffaf7';
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      return { src: canvas.toDataURL('image/jpeg', 0.85), filename: file.name };
    } catch (error) {
      throw new Error(error.message?.includes('图片') || error.message?.includes('浏览器') ? error.message : '这张图片暂时无法读取，请换成 JPG、PNG 或 WebP');
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  function syncPhotoCityField() {
    const form = $('#upload-form');
    const isTravel = form?.elements.namedItem('category')?.value === 'travel';
    if ($('#photo-city-field')) $('#photo-city-field').hidden = !isTravel;
    const cityInput = form?.elements.namedItem('city');
    if (cityInput && !isTravel) cityInput.value = '';
  }

  async function prepareUpload(files, uploadCity = cityFilter) {
    if (!requireOwner() || writeBusy || preparingUpload) return;
    if (!files.length) return;
    if (files.length > 30) { toast('一次最多添加 30 张照片，可以分几次慢慢收藏。'); return; }
    if (photos.length + files.length > 1000) { toast('相册已接近容量上限，请先导出备份并整理照片。'); return; }
    preparingUpload = true;
    updateCloudUI();
    toast('正在整理照片，请稍等一下…');
    try {
      const prepared = [];
      for (const file of files) prepared.push({ ...await compressPhoto(file), id: uid(), createdAt: Date.now() });
      pendingPhotos = prepared;
      const form = $('#upload-form');
      form?.reset();
      if (form?.elements.namedItem('title')) form.elements.namedItem('title').value = uploadCity ? `和${state.profile.girl}在${uploadCity}` : '我们的心动瞬间';
      if (form?.elements.namedItem('date')) form.elements.namedItem('date').value = today();
      if (uploadCity && form?.elements.namedItem('category')) form.elements.namedItem('category').value = 'travel';
      if (form?.elements.namedItem('city')) form.elements.namedItem('city').value = uploadCity;
      syncPhotoCityField();
      if ($('#upload-count')) $('#upload-count').textContent = `已选择 ${pendingPhotos.length} 张照片`;
      const preview = $('#upload-preview');
      if (preview?.tagName === 'IMG') preview.src = pendingPhotos[0].src;
      else if (preview) {
        preview.replaceChildren();
        pendingPhotos.slice(0, 4).forEach(photo => {
          const image = element('img'); image.src = photo.src; image.alt = '待添加照片预览'; preview.append(image);
        });
      }
      openDialog('#upload-dialog');
      toast('照片准备好了，给这段回忆起个名字吧。');
    } catch (error) {
      pendingPhotos = [];
      toast(error.message || '照片读取失败，请重新选择。');
    } finally {
      preparingUpload = false;
      updateCloudUI();
    }
  }

  function validateState(data) {
    if (!data || typeof data !== 'object' || !data.profile || !Array.isArray(data.memories) || !Array.isArray(data.wishes)) throw new Error('备份格式不正确，请选择从这个小窝导出的文件。');
    const profile = data.profile;
    if (!plain(profile.girl, 30) || !plain(profile.boy, 30) || !validDate(profile.metDate) || profile.metDate > today() || !plain(profile.place, 50)) throw new Error('备份中的昵称或相遇日期不正确。');
    if (data.memories.length > 1000 || data.wishes.length > 1000) throw new Error('备份内容太多，暂时无法导入。');
    const memories = data.memories.map(memory => {
      if (!memory || !validDate(memory.date) || !plain(memory.title, 80)) throw new Error('备份中的回忆格式不正确。');
      return { id: plain(memory.id, 100) || uid(), date: memory.date, title: plain(memory.title, 80), description: plain(memory.description, 1000) };
    });
    const wishes = data.wishes.map(wish => {
      if (!wish || typeof wish.done !== 'boolean' || !plain(wish.text, 100)) throw new Error('备份中的愿望格式不正确。');
      return { id: plain(wish.id, 100) || uid(), text: plain(wish.text, 100), done: wish.done };
    });
    return {
      profile: { girl: plain(profile.girl, 30), boy: plain(profile.boy, 30), metDate: profile.metDate, place: plain(profile.place, 50) },
      memories, wishes,
      letter: data.letter === null || data.letter === undefined ? null : String(data.letter).slice(0, 10000),
      letterDate: validDate(data.letterDate) ? data.letterDate : null,
    };
  }

  function validateBackupPhotos(items) {
    if (!Array.isArray(items) || items.length > 1000) throw new Error('备份中的相册格式不正确。');
    const ids = new Set();
    return items.map(photo => {
      if (!photo || !/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+=*$/.test(photo.src) || photo.src.length > 12 * 1024 * 1024 || !validDate(photo.date) || !['us', 'daily', 'travel'].includes(photo.category)) throw new Error('备份中有无法读取的照片。');
      const city = photo.city === undefined ? '' : photo.city;
      if (typeof city !== 'string' || (city !== '' && !CITIES.includes(city))) throw new Error('备份中的旅行城市不正确。');
      const id = plain(photo.id, 100) || uid();
      if (ids.has(id)) throw new Error('备份中有重复的照片，请重新导出后再试。');
      ids.add(id);
      return { id, src: photo.src, title: plain(photo.title, 80) || '我们的心动瞬间', date: photo.date, category: photo.category, city, createdAt: Number.isFinite(photo.createdAt) ? photo.createdAt : Date.now() };
    });
  }

  function blobDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(new Error('云端图片暂时无法转换成备份，请稍后重试。'));
      reader.readAsDataURL(blob);
    });
  }

  async function exportBackup() {
    await ownerAction($('#export-data'), async () => {
      const snapshot = clone(state);
      const cloudPhotos = [...photos];
      const savedPhotos = [];
      for (let index = 0; index < cloudPhotos.length; index++) {
        const photo = cloudPhotos[index];
        const blob = await api(photo.src, {}, 'blob');
        if (!/^image\/(jpeg|png|webp)(;|$)/.test(blob.type)) throw new Error('有一张云端照片暂时无法备份，请刷新后重试。');
        savedPhotos.push({ ...photo, src: await blobDataUrl(blob) });
        if ($('#cloud-status')) $('#cloud-status').textContent = `正在备份云端照片 ${index + 1} / ${cloudPhotos.length}`;
      }
      const backup = { version: 1, exportedAt: new Date().toISOString(), ...snapshot, photos: savedPhotos };
      if (backup.letter === null) backup.letter = initialLetter;
      const url = URL.createObjectURL(new Blob([JSON.stringify(backup)], { type: 'application/json' }));
      const link = element('a');
      link.href = url;
      link.download = `${state.profile.girl}与${state.profile.boy}的云端回忆备份-${today()}.json`;
      document.body.append(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 30000);
      toast(`已备份云端手账和 ${savedPhotos.length} 张共享照片。本机未同步照片未混入其中。`);
    });
  }

  async function importBackup(file) {
    if (!file) return;
    await ownerAction($('#import-data'), async () => {
      let contents;
      try { contents = await file.text(); }
      catch { throw new Error('浏览器暂时无法完整读取这份备份，请关闭其他页面后再试。'); }
      let data;
      try { data = JSON.parse(contents); }
      catch { throw new Error('这不是有效的备份文件，请选择导出的 JSON 文件。'); }
      if (data.version !== 1) throw new Error('这个备份版本暂时无法读取。');
      const importedState = validateState(data);
      const importedPhotos = validateBackupPhotos(data.photos);
      if (!confirm(`将把备份中的 ${importedPhotos.length} 张照片合并到公开云端相册，不删除现有照片。全部照片成功后会用备份更新昵称、回忆、愿望和情书，所有访客可见。确定继续吗？`)) return;
      await preserveLocalPhotos(importedPhotos);
      const result = await uploadBatch(importedPhotos, (successful, failed, total) => {
        if ($('#cloud-status')) $('#cloud-status').textContent = `正在导入：成功 ${successful}，失败 ${failed}，共 ${total} 张`;
      });
      filter = 'all';
      cityFilter = '';
      renderAlbum();
      if (result.failed.length) {
        toast(`已共享 ${result.successful.length} 张，${result.failed.length} 张未成功，手账尚未替换。${result.retiredIds.length ? failedUploadHint(result) : '重新导入同一备份可安全重试，已有照片不会重复。'}`);
        return;
      }
      await saveState(importedState);
      closeDialog('#settings-dialog');
      toast(`备份中的 ${importedPhotos.length} 张照片与手账已共享到云端，原有照片也都保留着 ♡`);
    });
  }

  async function toggleMusic() {
    const button = $('#music-toggle');
    if (!button || musicBusy) return;
    musicBusy = true;
    if (musicTimer) {
      clearInterval(musicTimer);
      musicTimer = null;
      try { await musicContext?.suspend(); } catch { /* The context may already have been closed by the browser. */ }
      button.setAttribute('aria-pressed', 'false');
      button.classList.remove('is-playing');
      toast('小窝的音乐暂停了。');
      musicBusy = false;
      return;
    }
    try {
      const AudioContext = globalThis.AudioContext || globalThis.webkitAudioContext;
      if (!AudioContext) throw new Error('no audio');
      if (!musicContext) musicContext = new AudioContext();
      await musicContext.resume();
      const melody = [523.25, 659.25, 783.99, 659.25, 587.33, 698.46, 659.25, 523.25];
      let note = 0;
      const play = () => {
        if (musicContext.state !== 'running') return;
        const time = musicContext.currentTime;
        const oscillator = musicContext.createOscillator();
        const gain = musicContext.createGain();
        oscillator.type = 'sine';
        oscillator.frequency.value = melody[note++ % melody.length];
        gain.gain.setValueAtTime(0, time);
        gain.gain.linearRampToValueAtTime(0.075, time + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 1.1);
        oscillator.connect(gain);
        gain.connect(musicContext.destination);
        oscillator.start(time);
        oscillator.stop(time + 1.2);
        oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
      };
      play();
      musicTimer = setInterval(play, 580);
      button.setAttribute('aria-pressed', 'true');
      button.classList.add('is-playing');
      toast('给小窝放一段轻轻的八音盒旋律 ♪');
    } catch {
      toast('浏览器暂时无法播放音乐，请稍后再试。');
    } finally { musicBusy = false; }
  }

  function bindEvents() {
    $$('dialog').forEach(dialog => {
      $$('[data-close-dialog]', dialog).forEach(button => button.addEventListener('click', () => dialog.close()));
      dialog.addEventListener('click', event => {
        if (event.target !== dialog) return;
        const bounds = dialog.getBoundingClientRect();
        if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close();
      });
    });
    $$('[data-open-settings]').forEach(button => button.addEventListener('click', () => {
      if (!requireOwner() || writeBusy) return;
      const form = $('#settings-form');
      if (form) Object.entries(state.profile).forEach(([name, value]) => { if (form.elements.namedItem(name)) form.elements.namedItem(name).value = value; });
      if (form?.elements.namedItem('metDate')) form.elements.namedItem('metDate').max = today();
      openDialog('#settings-dialog');
    }));
    $('#settings-form')?.addEventListener('submit', async event => {
      event.preventDefault();
      const form = event.currentTarget;
      const profile = { girl: formValue(form, 'girl', 30), boy: formValue(form, 'boy', 30), metDate: formValue(form, 'metDate', 10), place: formValue(form, 'place', 50) };
      if (!profile.girl || !profile.boy || !profile.place || !validDate(profile.metDate) || profile.metDate > today()) { toast('请填写昵称、地点和已经到来的相遇日期。'); return; }
      await ownerAction(form, async () => {
        const candidate = clone(state);
        candidate.profile = profile;
        const first = candidate.memories.find(memory => memory.id === 'first-meeting');
        if (first) { first.date = profile.metDate; first.title = `初遇，在${profile.place}`; first.description = `在${profile.place}听音乐时，我们认识了。那一天，故事开始有了我们。`; }
        await saveState(candidate);
        closeDialog('#settings-dialog');
        toast('属于我们的名字和相遇，已经同步到云端 ♡');
      });
    });
    $$('[data-upload]').forEach(button => button.addEventListener('click', () => { if (requireOwner() && !writeBusy && !preparingUpload) $('#photo-input')?.click(); }));
    $('#photo-input')?.addEventListener('change', event => {
      const files = [...event.currentTarget.files];
      event.currentTarget.value = '';
      prepareUpload(files);
    });
    $('#upload-form')?.elements.namedItem('category')?.addEventListener('change', syncPhotoCityField);
    syncPhotoCityField();
    $('#upload-form')?.addEventListener('submit', async event => {
      event.preventDefault();
      if (!pendingPhotos.length) { toast('请先选择照片。'); return; }
      const form = event.currentTarget;
      const date = formValue(form, 'date', 10);
      const title = formValue(form, 'title', 80) || '我们的心动瞬间';
      const category = formValue(form, 'category', 10);
      if (!validDate(date) || !['us', 'daily', 'travel'].includes(category)) { toast('请填写照片日期和分类。'); return; }
      const city = category === 'travel' ? formValue(form, 'city', 10) : '';
      if (city && !CITIES.includes(city)) { toast('请选择这次旅行的城市。'); return; }
      await ownerAction(form, async () => {
        const items = pendingPhotos.map((photo, index) => {
          if (!photo.uploadRecord) photo.uploadRecord = { id: photo.id, src: photo.src, title: pendingPhotos.length === 1 ? title : `${title} ${index + 1}`, date, category, city, createdAt: photo.createdAt + index };
          return photo.uploadRecord;
        });
        await preserveLocalPhotos(items);
        const result = await uploadBatch(items, (successful, failed, total) => {
          if ($('#upload-count')) $('#upload-count').textContent = `已成功 ${successful} 张，失败 ${failed} 张，共 ${total} 张`;
        });
        const failedIds = new Set(result.failed.map(photo => photo.id));
        pendingPhotos = pendingPhotos.filter(photo => failedIds.has(photo.id));
        filter = city ? 'travel' : 'all';
        cityFilter = city;
        renderAlbum();
        if (result.failed.length) {
          if ($('#upload-count')) $('#upload-count').textContent = `已成功 ${result.successful.length} 张，剩余 ${result.failed.length} 张待重试`;
          if ($('#upload-preview')?.tagName === 'IMG') $('#upload-preview').src = pendingPhotos[0].src;
          toast(`已共享 ${result.successful.length} 张，${result.failed.length} 张未成功。${result.retiredIds.length ? failedUploadHint(result) : '再次点击收藏可重试，不会重复添加。'}`);
        } else {
          closeDialog('#upload-dialog');
          toast(`收藏好了 ${items.length} 个心动瞬间 ♡ 现在大家都能在云端看到。`);
        }
      });
    });
    $$('#album-filters [data-filter]').forEach(button => button.addEventListener('click', () => { filter = button.dataset.filter; cityFilter = ''; renderAlbum(); }));
    $$('[data-city]').forEach(button => button.addEventListener('click', () => {
      if (!CITIES.includes(button.dataset.city)) return;
      cityFilter = button.dataset.city;
      filter = 'travel';
      renderAlbum();
      const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
      $('#album')?.scrollIntoView({ behavior: reducedMotion ? 'instant' : 'smooth', block: 'start' });
    }));
    $('#clear-city-filter')?.addEventListener('click', () => { cityFilter = ''; filter = 'travel'; renderAlbum(); });
    $$('[data-photo-prev]').forEach(button => button.addEventListener('click', () => navigatePhoto(-1)));
    $$('[data-photo-next]').forEach(button => button.addEventListener('click', () => navigatePhoto(1)));
    $('#lightbox-dialog')?.addEventListener('keydown', event => {
      if (event.key === 'ArrowLeft') { event.preventDefault(); navigatePhoto(-1); }
      if (event.key === 'ArrowRight') { event.preventDefault(); navigatePhoto(1); }
    });
    $('#photo-delete')?.addEventListener('click', async () => {
      const photo = lightboxItems[lightboxIndex];
      if (!photo || photo.sample) return;
      await ownerAction($('#photo-delete'), async () => {
        if (!confirm('要把这张照片移出公开的云端相册吗？本机备份会保留。')) return;
        await api(`/api/photos/${encodeURIComponent(photo.id)}`, { method: 'DELETE' });
        photos = photos.filter(item => item.id !== photo.id);
        lightboxItems = lightboxItems.filter(item => item.id !== photo.id);
        if (!lightboxItems.length) closeDialog('#lightbox-dialog');
        else { lightboxIndex = Math.min(lightboxIndex, lightboxItems.length - 1); renderLightbox(); }
        renderAlbum();
        toast('照片已从云端相册移除，本机备份保留着。');
      });
    });
    $('#add-memory')?.addEventListener('click', () => {
      if (!requireOwner() || writeBusy) return;
      const form = $('#memory-form'); form?.reset();
      if (form?.elements.namedItem('date')) form.elements.namedItem('date').value = today();
      openDialog('#memory-dialog');
    });
    $('#memory-form')?.addEventListener('submit', async event => {
      event.preventDefault();
      const form = event.currentTarget;
      const title = formValue(form, 'title', 80), date = formValue(form, 'date', 10), description = formValue(form, 'description', 1000);
      if (!title || !validDate(date)) { toast('给这段回忆写上名字和日期吧。'); return; }
      if (state.memories.length >= 1000) { toast('回忆太多啦，请先导出备份。'); return; }
      await ownerAction(form, async () => {
        const candidate = clone(state);
        candidate.memories.push({ id: uid(), title, date, description });
        await saveState(candidate);
        closeDialog('#memory-dialog');
        toast('这一天，已经被云端好好记住了 ♡');
      });
    });
    $('#wish-form')?.addEventListener('submit', async event => {
      event.preventDefault();
      const form = event.currentTarget, text = formValue(form, 'wish', 100);
      if (!text) { toast('写下一件想和她一起做的小事吧。'); return; }
      if (state.wishes.length >= 1000) { toast('愿望太多啦，先一起完成几件吧。'); return; }
      await ownerAction(form, async () => {
        const candidate = clone(state);
        candidate.wishes.push({ id: uid(), text, done: false });
        await saveState(candidate);
        form.reset();
        toast('新的小愿望，已经同步到云端。');
      });
    });
    $('#edit-letter')?.addEventListener('click', () => {
      if (!requireOwner() || writeBusy) return;
      const input = $('#letter-form')?.elements.namedItem('letter');
      if (input) input.value = $('#letter-text')?.textContent.trim() || '';
      openDialog('#letter-dialog');
    });
    $('#letter-form')?.addEventListener('submit', async event => {
      event.preventDefault();
      const text = formValue(event.currentTarget, 'letter', 10000);
      if (!text) { toast('写下一点想对她说的话吧。'); return; }
      await ownerAction(event.currentTarget, async () => {
        const candidate = clone(state);
        candidate.letter = text; candidate.letterDate = today();
        await saveState(candidate);
        closeDialog('#letter-dialog');
        toast('这封小情书，已经同步到云端 ♡');
      });
    });
    $('#surprise-button')?.addEventListener('click', () => {
      const lines = [`今日份喜欢，全部留给${state.profile.girl} ♡`, '世界很大，刚好我们遇见了。', '一起走的路，连晚风都是甜的。', '平凡的小日子，因为有你，变得闪闪发光。', '想把今天的小开心，第一个讲给你听。'];
      toast(lines[Math.floor(Math.random() * lines.length)]);
    });
    $('#music-toggle')?.addEventListener('click', toggleMusic);
    $('#export-data')?.addEventListener('click', exportBackup);
    $('#import-data')?.addEventListener('click', () => $('#import-input')?.click());
    $('#import-input')?.addEventListener('change', event => { const file = event.currentTarget.files[0]; event.currentTarget.value = ''; importBackup(file); });
    $('#cloud-refresh')?.addEventListener('click', refreshCloud);
    $('#sync-local-photos')?.addEventListener('click', async () => {
      if (!requireOwner() || writeBusy) return;
      try { localPhotos = await readPhotos(); }
      catch { toast('本机照片暂时无法读取，请使用之前导出的回忆备份。'); return; }
      renderMigrationList();
      if ($('#migration-status')) $('#migration-status').textContent = '请确认勾选的照片。同步后，所有访客都可以看到它们。';
      openDialog('#migration-dialog');
    });
    $('#select-all-local')?.addEventListener('click', event => {
      if (!requireOwner() || writeBusy) return;
      const checked = event.currentTarget.type === 'checkbox' ? event.currentTarget.checked : true;
      $$('#migration-list input[type="checkbox"]').forEach(input => { input.checked = checked; });
      updateLocalSelection();
    });
    $('#migration-form')?.addEventListener('submit', async event => {
      event.preventDefault();
      const form = event.currentTarget;
      const ids = new Set($$('#migration-list input[type="checkbox"]:checked').map(input => input.value));
      if (!ids.size) { toast('先勾选想公开分享的照片吧。'); return; }
      await ownerAction(form, async () => {
        const selected = validateBackupPhotos(localPhotos.filter(photo => ids.has(photo.id)));
        const result = await uploadBatch(selected, migrationProgress);
        const failedIds = new Set(result.failed.map(photo => photo.id));
        renderMigrationList(failedIds);
        migrationProgress(result.successful.length, result.failed.length, selected.length);
        if (result.retiredIds.length && $('#migration-status')) $('#migration-status').textContent += failedUploadHint(result);
        filter = 'all'; cityFilter = ''; renderAlbum();
        toast(result.failed.length ? `已共享 ${result.successful.length} 张，${result.failed.length} 张未成功。${failedUploadHint(result)}本机照片都保留着。` : `已把 ${result.successful.length} 张勾选照片共享到云端，本机备份也都保留着 ♡`);
      });
    });
    const links = $$('nav a[href^="#"]');
    if ('IntersectionObserver' in window && links.length) {
      const observer = new IntersectionObserver(entries => {
        const visible = entries.filter(entry => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (!visible) return;
        links.forEach(link => {
          const active = link.getAttribute('href') === `#${visible.target.id}`;
          link.classList.toggle('active', active);
          if (active) link.setAttribute('aria-current', 'location'); else link.removeAttribute('aria-current');
        });
      }, { rootMargin: '-15% 0px -55% 0px', threshold: [0, 0.15, 0.4] });
      links.forEach(link => { const target = $(link.getAttribute('href')); if (target) observer.observe(target); });
    }
  }

  async function init() {
    initialLetter = $('#letter-text')?.textContent.trim() || '';
    try {
      const stored = localStorage.getItem(KEY);
      if (stored) localState = validateState(JSON.parse(stored));
    } catch { /* Public visitors never need access to a local diary. */ }
    state = defaults();
    state.letter = initialLetter;
    renderAll();
    if ($('#settings-storage')) $('#settings-storage').textContent = '共享照片和手账保存在云端，所有访客都能看到，只有主人可以修改。本机旧照片会保留；请确认勾选后再同步，也可以导入回忆备份。';
    try {
      const stored = await readStoredDiary();
      if (stored.diary) localState = validateState(stored.diary);
      localPhotos = stored.photos;
    } catch { /* Local backup access must not prevent cloud viewing. */ }
    bindEvents();
    updateCloudUI();
    await refreshCloud();
    // Refresh the day count across midnight without changing the chosen timezone.
    setInterval(renderProfile, 60000);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
