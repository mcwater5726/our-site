CREATE TABLE photos (
 id TEXT PRIMARY KEY NOT NULL,
 title TEXT NOT NULL,
 photo_date TEXT NOT NULL,
 category TEXT NOT NULL,
 city TEXT NOT NULL DEFAULT '',
 object_key TEXT NOT NULL,
 content_type TEXT NOT NULL,
 created_at INTEGER NOT NULL,
 deleted_at INTEGER
);
--> statement-breakpoint
CREATE INDEX photos_active_date ON photos (deleted_at, photo_date, created_at);
--> statement-breakpoint
CREATE TABLE diary (
 id INTEGER PRIMARY KEY CHECK (id = 1),
 content TEXT NOT NULL,
 revision INTEGER NOT NULL DEFAULT 1
);

