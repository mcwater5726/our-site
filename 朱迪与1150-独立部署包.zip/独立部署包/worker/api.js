const CITIES = new Set(['泉州','青岛','苏州','厦门','连云港','南京','镇江','扬州']);
const ID = /^[A-Za-z0-9][A-Za-z0-9_-]{0,99}$/;
const MAX_UPLOAD_BODY = 8 * 1024 * 1024;
class ApiError extends Error { constructor(message,status=400){super(message);this.status=status;} }
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const dateOK=value=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&!Number.isNaN(Date.parse(value+'T00:00:00Z'))&&new Date(value+'T00:00:00Z').toISOString().slice(0,10)===value;
const text=(value,max,required=true)=>{if(typeof value!=='string'||value.length>max||(required&&!value.trim()))throw new ApiError('填写的文字不完整或太长了。');return value.trim();};
const idOK=id=>typeof id==='string'&&ID.test(id);
function identity(request,env){
 const id=request.headers.get('oai-authenticated-user-id')?.trim();
 const email=request.headers.get('oai-authenticated-user-email')?.trim().toLowerCase();
 return {authenticated:Boolean(id&&email),canEdit:Boolean(id&&email&&env.OWNER_EMAIL&&email===env.OWNER_EMAIL.trim().toLowerCase())};
}
function requireOwner(request,env){
 const user=identity(request,env);
 if(!user.authenticated)throw new ApiError('请先登录主人的账号，再管理相册。',401);
 if(!user.canEdit)throw new ApiError('这个小窝只有主人可以修改，你可以安心浏览。',403);
 if(request.headers.get('Origin')!==new URL(request.url).origin)throw new ApiError('请从小窝页面操作。',403);
 if(request.headers.get('Sec-Fetch-Site')==='cross-site')throw new ApiError('请从小窝页面操作。',403);
}
async function readJSON(request,limit){
 if(!request.headers.get('Content-Type')?.toLowerCase().startsWith('application/json'))throw new ApiError('请使用正确的照片或手账格式。',415);
 const length=request.headers.get('Content-Length');
 if(length&&Number(length)>limit)throw new ApiError('这份内容太大了，请减少后重试。',413);
 const reader=request.body?.getReader(); if(!reader)throw new ApiError('没有收到要保存的内容。');
 const parts=[]; let size=0;
 try {while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>limit){await reader.cancel();throw new ApiError('这份内容太大了，请减少后重试。',413);}parts.push(value);}}
 finally {reader.releaseLock();}
 const buffer=new Uint8Array(size);let at=0;for(const part of parts){buffer.set(part,at);at+=part.length;}
 try{return JSON.parse(new TextDecoder().decode(buffer));}catch{throw new ApiError('内容格式不正确，请重新选择。');}
}
function photoFromRow(row){
 return {id:row.id,src:'/api/images/'+row.id,title:row.title,date:row.photo_date,category:row.category,city:row.city||'',createdAt:row.created_at};
}
function validatePhoto(data){
 if(!data||!idOK(data.id))throw new ApiError('照片编号不正确。');
 const title=text(data.title,80);if(!dateOK(data.date))throw new ApiError('请填写有效的照片日期。');
 if(!['us','daily','travel'].includes(data.category))throw new ApiError('请选择照片分类。');
 const city=data.city??'';if(typeof city!=='string'||(city&&!CITIES.has(city)))throw new ApiError('请选择正确的旅行城市。');
 if(typeof data.src!=='string')throw new ApiError('没有收到图片。');
 const match=/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/.exec(data.src);
 if(!match||match[2].length%4!==0)throw new ApiError('照片格式暂不支持，请选择JPG、PNG或WebP。');
 let raw;try{raw=atob(match[2]);}catch{throw new ApiError('图片内容不完整，请重新选择。');}
 if(raw.length>6*1024*1024)throw new ApiError('图片太大了，请压缩后重试。',413);
 const bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));
 const jpg=bytes.length>3&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255;
 const png=bytes.length>8&&[137,80,78,71,13,10,26,10].every((n,i)=>bytes[i]===n);
 const webp=bytes.length>12&&new TextDecoder().decode(bytes.slice(0,4))==='RIFF'&&new TextDecoder().decode(bytes.slice(8,12))==='WEBP';
 if(!(match[1]==='jpeg'&&jpg||match[1]==='png'&&png||match[1]==='webp'&&webp))throw new ApiError('这张图片无法识别，请重新选择。');
 return {id:data.id,title,date:data.date,category:data.category,city:data.category==='travel'?city:'',createdAt:Number.isSafeInteger(data.createdAt)&&data.createdAt>0?data.createdAt:Date.now(),bytes,contentType:'image/'+match[1]};
}
function validateDiary(data){
 if(!data||typeof data!=='object'||!data.profile||!Array.isArray(data.memories)||!Array.isArray(data.wishes))throw new ApiError('手账内容格式不正确。');
 const p=data.profile;
 if(!dateOK(p.metDate)||p.metDate>today())throw new ApiError('请填写已经到来的相遇日期。');
 if(data.memories.length>1000||data.wishes.length>1000)throw new ApiError('手账内容太多，请先整理。');
 const profile={girl:text(p.girl,30),boy:text(p.boy,30),metDate:p.metDate,place:text(p.place,50)};
 const memories=data.memories.map(m=>{if(!m||!idOK(m.id)||!dateOK(m.date))throw new ApiError('回忆的编号或日期不正确。');return {id:m.id,title:text(m.title,80),date:m.date,description:text(m.description??'',1000,false)};});
 const wishes=data.wishes.map(w=>{if(!w||!idOK(w.id)||typeof w.done!=='boolean')throw new ApiError('愿望格式不正确。');return {id:w.id,text:text(w.text,100),done:w.done};});
 if(data.letter!==null&&data.letter!==undefined&&typeof data.letter!=='string')throw new ApiError('情书格式不正确。');
 if(data.letter&&data.letter.length>10000)throw new ApiError('这封信太长了，请精简一点。');
 if(data.letterDate!=null&&!dateOK(data.letterDate))throw new ApiError('情书日期不正确。');
 return {profile,memories,wishes,letter:data.letter??null,letterDate:data.letterDate??null};
}
async function savePhoto(data,env){
 const photo=validatePhoto(data);
 let existing=await env.DB.prepare('SELECT * FROM photos WHERE id = ?').bind(photo.id).first();
 if(existing){
  if(existing.deleted_at!=null)throw new ApiError('这张照片之前已从云端移除。如要重新收藏，请作为新照片添加。',410);
  return photoFromRow(existing);
 }
 const {n}=await env.DB.prepare('SELECT COUNT(*) AS n FROM photos WHERE deleted_at IS NULL').first();
 if(n>=1000)throw new ApiError('相册已经有1000张照片，请先整理再添加。',409);
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',photo.bytes));
 const digest=Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('');
 const key='photos/'+photo.id+'/'+digest;
 await env.BUCKET.put(key,photo.bytes,{httpMetadata:{contentType:photo.contentType,cacheControl:'no-store'}});
 try{
  const result=await env.DB.prepare('INSERT OR IGNORE INTO photos (id,title,photo_date,category,city,object_key,content_type,created_at,deleted_at) VALUES (?,?,?,?,?,?,?,?,NULL)').bind(photo.id,photo.title,photo.date,photo.category,photo.city,key,photo.contentType,photo.createdAt).run();
  existing=await env.DB.prepare('SELECT * FROM photos WHERE id = ?').bind(photo.id).first();
  if(!existing)throw new Error('Photo record was not committed');
  if(result.meta?.changes===0&&existing.object_key!==key)await env.BUCKET.delete(key);
  return photoFromRow(existing);
 }catch(error){
  // A commit can succeed even if its response is interrupted: keep any referenced object.
  try{const saved=await env.DB.prepare('SELECT object_key FROM photos WHERE id = ?').bind(photo.id).first();if(saved?.object_key!==key)await env.BUCKET.delete(key);}catch{}
  throw error;
 }
}
export async function handleApi(request,env){
 try{
  const url=new URL(request.url), path=url.pathname, method=request.method;
  if(path==='/api/session'&&method==='GET')return json({...identity(request,env),loginUrl:'/signin-with-chatgpt?return_to=%2F'});
  if(!env.DB||!env.BUCKET)throw new ApiError('云端相册正在准备，请稍后刷新。',503);
  if(path==='/api/photos'&&method==='GET'){
   const result=await env.DB.prepare('SELECT * FROM photos WHERE deleted_at IS NULL ORDER BY photo_date DESC, created_at DESC').all();
   const photos=result.results.map(photoFromRow);return json({photos,count:photos.length});
  }
  const imageMatch=/^\/api\/images\/([^/]+)$/.exec(path);
  if(imageMatch&&(method==='GET'||method==='HEAD')){
   const id=imageMatch[1];if(!idOK(id))throw new ApiError('这张照片不存在。',404);
   const row=await env.DB.prepare('SELECT * FROM photos WHERE id = ? AND deleted_at IS NULL').bind(id).first();
   if(!row)throw new ApiError('这张照片不存在。',404);
   const object=await env.BUCKET.get(row.object_key);if(!object)throw new ApiError('照片暂时无法读取，请稍后再试。',404);
   return new Response(method==='HEAD'?null:object.body,{headers:{'Content-Type':row.content_type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'"}});
  }
  if(path==='/api/diary'&&method==='GET'){
   const row=await env.DB.prepare('SELECT content, revision FROM diary WHERE id = 1').first();
   return json({diary:row?JSON.parse(row.content):null,revision:row?.revision||0});
  }
  if(!['POST','PUT','DELETE'].includes(method))throw new ApiError('没有这个小窝功能。',404);
  requireOwner(request,env);
  if(path==='/api/photos'&&method==='POST')return json({photo:await savePhoto(await readJSON(request,MAX_UPLOAD_BODY),env)},201);
  const photoMatch=/^\/api\/photos\/([^/]+)$/.exec(path);
  if(photoMatch&&method==='DELETE'){
   const id=photoMatch[1];if(!idOK(id))throw new ApiError('照片编号不正确。');
   await env.DB.prepare('UPDATE photos SET deleted_at = ? WHERE id = ? AND deleted_at IS NULL').bind(Date.now(),id).run();
   return json({ok:true});
  }
  if(path==='/api/diary'&&method==='PUT'){
   const data=await readJSON(request,4*1024*1024);
   const diary=validateDiary(data?.diary), revision=data?.revision;
   if(!Number.isSafeInteger(revision)||revision<0)throw new ApiError('请刷新页面后再保存。',409);
   const result=revision===0?
    await env.DB.prepare('INSERT OR IGNORE INTO diary (id,content,revision) VALUES (1,?,1)').bind(JSON.stringify(diary)).run():
    await env.DB.prepare('UPDATE diary SET content = ?, revision = revision + 1 WHERE id = 1 AND revision = ?').bind(JSON.stringify(diary),revision).run();
   if(!result.meta?.changes)throw new ApiError('另一处刚刚更新了手账，请刷新后再继续，已有内容没有被覆盖。',409);
   return json({revision:revision+1});
  }
  throw new ApiError('没有这个小窝功能。',404);
 }catch(error){if(error instanceof ApiError)return json({error:error.message},error.status);console.error('Cloud album operation failed');return json({error:'云端暂时没有保存成功，请稍后重试。本机照片仍会保留。'},503);}
}

