import http from 'node:http';
import { readFile, writeFile, mkdir, realpath } from 'node:fs/promises';
import { resolve, join, extname, relative, isAbsolute, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { randomBytes, createHmac, scryptSync, timingSafeEqual } from 'node:crypto';
import { createLocalEnv } from '../scripts/local-env.mjs';
import { handleApi } from '../worker/api.js';

const ROOT = resolve(fileURLToPath(new URL('..', import.meta.url)));
const PUBLIC_ROOT = join(ROOT, 'public');
const COOKIE = 'bunny_owner';
const SESSION_SECONDS = 7 * 24 * 60 * 60;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const MAX_FAILURES = 10;
const INTERNAL_EMAIL = 'owner@portable.invalid';
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.webp': 'image/webp', '.gif': 'image/gif', '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8', '.txt': 'text/plain; charset=utf-8',
};

function originConfig(value) {
  if (!value) return null;
  const parsed = new URL(value);
  if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password || parsed.search || parsed.hash || parsed.pathname !== '/') throw new Error('PUBLIC_ORIGIN must be an HTTP(S) origin without a path.');
  return parsed.origin;
}

function inside(root, filename) {
  const part = relative(root, filename);
  return part === '' || (!isAbsolute(part) && part !== '..' && !part.startsWith('..' + sep));
}

function effectiveOrigin(incoming, configured) {
  if (configured) return configured;
  const host = incoming.headers.host;
  if (typeof host !== 'string' || !/^(?:\[[0-9a-f:.]+\]|[a-z0-9.-]+)(?::\d{1,5})?$/i.test(host) || host.length > 300) throw Object.assign(new Error('Invalid Host header'), { status: 400 });
  return new URL('http://' + host).origin;
}

function response(body, status = 200, headers = {}) {
  return new Response(body, {
    status,
    headers: { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'Cache-Control': 'no-store', ...headers },
  });
}

function json(data, status = 200, headers = {}) {
  return response(JSON.stringify(data), status, { 'Content-Type': 'application/json; charset=utf-8', ...headers });
}

function loginPage(message = '', loggedIn = false) {
  return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>主人登录 · 朱迪与1150</title><style>' +
    'body{margin:0;min-height:100dvh;display:grid;place-items:center;background:#fff8f2;color:#66504b;font:15px/1.8 "Microsoft YaHei",sans-serif}main{width:min(370px,calc(100% - 64px));padding:32px 25px;background:#fffdf8;border:1px solid #ecd9d2;border-radius:18px;box-shadow:0 8px 35px #9b657012;text-align:center}h1{font-size:25px;margin:4px 0 12px}.bunny{font-size:36px;color:#d77991}p{color:#a1897c;font-size:13px}label{display:block;text-align:left;margin-top:23px;font-size:12px;color:#92796b}input{box-sizing:border-box;width:100%;padding:12px;border:1px solid #e3c9c9;border-radius:8px;background:#fffcf7;color:#66504b;font:inherit;margin:8px 0 16px}button{width:100%;border:0;border-radius:8px;padding:12px;background:#d77991;color:white;font:inherit;cursor:pointer}a{display:block;margin-top:18px;font-size:12px;color:#ae7a80}.message{color:#b64f69;min-height:1.8em}input:focus-visible,button:focus-visible,a:focus-visible{outline:3px solid #a2ad8c;outline-offset:3px}</style></head><body><main><div class="bunny" aria-hidden="true">♡</div><h1>' +
    (loggedIn ? '你已经回到小窝啦' : '欢迎回到我们的小窝') + '</h1><p>' +
    (loggedIn ? '主人登录已生效，可以管理共享照片与手账。' : '大家都能浏览，主人输入管理密码后可以编辑。') +
    '</p><p class="message" role="status">' + message + '</p>' +
    (loggedIn ? '<form method="post" action="/owner-logout"><button type="submit">退出主人账号</button></form>' : '<form method="post" action="/owner-login"><label>管理密码<input type="password" name="password" autocomplete="current-password" minlength="12" maxlength="1024" required autofocus></label><button type="submit">打开我的小窝</button></form>') +
    '<a href="/">返回小窝首页</a></main></body></html>';
}

async function readBody(incoming, limit) {
  const length = Number(incoming.headers['content-length']);
  if (Number.isFinite(length) && length > limit) { incoming.resume(); throw Object.assign(new Error('Request too large'), { status: 413 }); }
  const chunks = [];
  let size = 0;
  for await (const chunk of incoming) {
    size += chunk.length;
    if (size > limit) throw Object.assign(new Error('Request too large'), { status: 413 });
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function sessionSecret(dataDir) {
  const filename = join(dataDir, 'session_secret');
  try {
    await writeFile(filename, randomBytes(32), { flag: 'wx', mode: 0o600 });
  } catch (error) { if (error.code !== 'EEXIST') throw error; }
  const value = await readFile(filename);
  if (value.length !== 32) throw new Error('The local session secret is invalid. Restore its original 32-byte file.');
  return value;
}

export async function createPortableServer({ dataDir = join(ROOT, 'portable', 'data'), adminPassword, host = '127.0.0.1', port = 4175, publicOrigin } = {}) {
  if (typeof adminPassword !== 'string' || adminPassword.trim().length < 12 || adminPassword.length > 1024) throw new Error('ADMIN_PASSWORD must contain at least 12 non-padding characters and at most 1024 characters.');
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error('PORT must be a valid port number.');
  if (typeof host !== 'string' || !host.trim()) throw new Error('HOST must not be empty.');
  const configuredOrigin = originConfig(publicOrigin);
  const storage = resolve(dataDir);
  await mkdir(storage, { recursive: true });
  const secret = await sessionSecret(storage);
  const passwordHash = scryptSync(adminPassword, secret, 32);
  const signingKey = createHmac('sha256', secret).update('bunny-owner-session\0' + adminPassword).digest();
  const env = await createLocalEnv({ databasePath: join(storage, 'album.sqlite'), objectPath: join(storage, 'objects'), ownerEmail: INTERNAL_EMAIL });
  const attempts = new Map();

  function sign(payload) { return createHmac('sha256', signingKey).update(payload).digest(); }
  function makeToken() {
    const payload = Buffer.from(JSON.stringify({ v: 1, exp: Math.floor(Date.now() / 1000) + SESSION_SECONDS, nonce: randomBytes(16).toString('base64url') })).toString('base64url');
    return payload + '.' + sign(payload).toString('base64url');
  }
  function authenticated(incoming) {
    const cookies = String(incoming.headers.cookie || '').split(';');
    const entry = cookies.map(part => part.trim()).find(part => part.startsWith(COOKIE + '='));
    if (!entry) return false;
    const token = entry.slice(COOKIE.length + 1);
    if (token.length > 1024) return false;
    const parts = token.split('.');
    if (parts.length !== 2 || parts.some(part => !/^[A-Za-z0-9_-]+$/.test(part))) return false;
    try {
      const given = Buffer.from(parts[1], 'base64url');
      const expected = sign(parts[0]);
      if (given.length !== expected.length || !timingSafeEqual(given, expected)) return false;
      const data = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf8'));
      const now = Math.floor(Date.now() / 1000);
      return data.v === 1 && Number.isSafeInteger(data.exp) && data.exp > now && data.exp <= now + SESSION_SECONDS + 300;
    } catch { return false; }
  }
  function cookie(value, secure, expired = false) {
    return COOKIE + '=' + value + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=' + (expired ? 0 : SESSION_SECONDS) + (secure ? '; Secure' : '');
  }
  function sameOrigin(incoming, origin) {
    return incoming.headers.origin === origin && incoming.headers['sec-fetch-site'] !== 'cross-site';
  }
  function failureWindow(address) {
    const now = Date.now();
    for (const [key, value] of attempts) if (now - value.startedAt >= LOGIN_WINDOW_MS) attempts.delete(key);
    if (attempts.size > 4096) attempts.delete(attempts.keys().next().value);
    let record = attempts.get(address);
    if (!record) { record = { startedAt: now, failures: 0 }; attempts.set(address, record); }
    return record;
  }

  async function route(incoming) {
    const origin = effectiveOrigin(incoming, configuredOrigin);
    if (!incoming.url?.startsWith('/') || incoming.url.startsWith('//')) return json({ error: 'Invalid request path' }, 400);
    const url = new URL(incoming.url, origin);
    const method = incoming.method || 'GET';
    const signedIn = authenticated(incoming);
    const secure = new URL(origin).protocol === 'https:';

    if (url.pathname === '/owner-login') {
      if (method === 'GET' || method === 'HEAD') return response(method === 'HEAD' ? null : loginPage('', signedIn), 200, { 'Content-Type': 'text/html; charset=utf-8' });
      if (method !== 'POST') return json({ error: 'Method not allowed' }, 405, { Allow: 'GET, HEAD, POST' });
      if (!sameOrigin(incoming, origin)) return json({ error: '请从小窝的登录页面提交。' }, 403);
      if (!String(incoming.headers['content-type'] || '').toLowerCase().startsWith('application/x-www-form-urlencoded')) return json({ error: '请使用登录表单。' }, 415);
      const address = incoming.socket.remoteAddress || 'unknown';
      const record = failureWindow(address);
      if (record.failures >= MAX_FAILURES) {
        const retryAfter = Math.max(1, Math.ceil((LOGIN_WINDOW_MS - (Date.now() - record.startedAt)) / 1000));
        return response(loginPage('密码尝试次数太多，请稍后再试。'), 429, { 'Content-Type': 'text/html; charset=utf-8', 'Retry-After': String(retryAfter) });
      }
      const form = new URLSearchParams((await readBody(incoming, 16 * 1024)).toString('utf8'));
      const supplied = form.get('password') || '';
      const suppliedHash = supplied.length <= 1024 ? scryptSync(supplied, secret, 32) : Buffer.alloc(32);
      if (!timingSafeEqual(suppliedHash, passwordHash)) {
        record.failures++;
        return response(loginPage('管理密码不正确，请重新输入。'), 401, { 'Content-Type': 'text/html; charset=utf-8' });
      }
      attempts.delete(address);
      return response(null, 303, { Location: '/', 'Set-Cookie': cookie(makeToken(), secure) });
    }

    if (url.pathname === '/owner-logout') {
      if (method !== 'POST') return json({ error: 'Method not allowed' }, 405, { Allow: 'POST' });
      if (!sameOrigin(incoming, origin)) return json({ error: '请从小窝页面退出。' }, 403);
      return response(null, 303, { Location: '/', 'Set-Cookie': cookie('', secure, true) });
    }

    if (url.pathname.startsWith('/api/')) {
      const headers = new Headers();
      Object.entries(incoming.headers).forEach(([name, value]) => { if (value != null) headers.set(name, Array.isArray(value) ? value.join(', ') : value); });
      // Incoming OpenAI-style identity headers are always untrusted on this independent server.
      headers.delete('oai-authenticated-user-id');
      headers.delete('oai-authenticated-user-email');
      if (signedIn) {
        headers.set('oai-authenticated-user-id', 'portable-owner');
        headers.set('oai-authenticated-user-email', INTERNAL_EMAIL);
      }
      const init = { method, headers };
      if (!['GET', 'HEAD'].includes(method)) init.body = await readBody(incoming, 9 * 1024 * 1024);
      const result = await handleApi(new Request(url, init), env);
      if (url.pathname === '/api/session' && method === 'GET' && result.ok) {
        const details = await result.json();
        return json({ ...details, loginUrl: '/owner-login' });
      }
      return result;
    }

    if (!['GET', 'HEAD'].includes(method)) return json({ error: 'Method not allowed' }, 405, { Allow: 'GET, HEAD' });
    let pathname;
    try { pathname = decodeURIComponent(url.pathname); } catch { return response('Not found', 404); }
    if (pathname.includes('\0') || pathname.includes('\\')) return response('Not found', 404);
    const file = resolve(PUBLIC_ROOT, '.' + (pathname === '/' ? '/index.html' : pathname));
    if (!inside(PUBLIC_ROOT, file)) return response('Not found', 404);
    let actual;
    try { actual = await realpath(file); } catch (error) { if (error.code === 'ENOENT' || error.code === 'ENOTDIR') return response('Not found', 404); throw error; }
    if (!inside(PUBLIC_ROOT, actual)) return response('Not found', 404);
    let body = await readFile(actual);
    const type = MIME[extname(actual).toLowerCase()] || 'application/octet-stream';
    if (extname(actual).toLowerCase() === '.html') body = Buffer.from(body.toString('utf8').replaceAll('/signin-with-chatgpt?return_to=%2F', '/owner-login'));
    return response(method === 'HEAD' ? null : body, 200, { 'Content-Type': type, 'Cache-Control': 'no-cache' });
  }

  const server = http.createServer(async (incoming, outgoing) => {
    try {
      const result = await route(incoming);
      outgoing.writeHead(result.status, Object.fromEntries(result.headers.entries()));
      outgoing.end(incoming.method === 'HEAD' ? undefined : Buffer.from(await result.arrayBuffer()));
    } catch (error) {
      const status = Number.isInteger(error.status) ? error.status : error.code === 'ENOENT' || error.code === 'EISDIR' ? 404 : 500;
      const result = json({ error: status === 413 ? '这份内容太大了，请减少后重试。' : status === 400 ? '请求格式不正确。' : status === 404 ? '没有找到这个页面。' : '小窝暂时无法处理请求，请稍后重试。' }, status);
      if (!outgoing.headersSent) outgoing.writeHead(result.status, Object.fromEntries(result.headers.entries()));
      outgoing.end(await result.text());
    }
  });
  server.requestTimeout = 30000;
  server.headersTimeout = 15000;
  server.keepAliveTimeout = 5000;
  server.maxHeadersCount = 60;

  await new Promise((accept, reject) => {
    server.once('error', reject);
    server.listen(port, host, () => { server.removeListener('error', reject); accept(); });
  }).catch(error => { env.close(); throw error; });
  const actual = server.address();
  const connectHost = host === '0.0.0.0' ? '127.0.0.1' : host === '::' ? '::1' : host;
  const address = 'http://' + (connectHost.includes(':') ? '[' + connectHost + ']' : connectHost) + ':' + actual.port;
  let closed = false;
  return {
    server, env, address,
    async close() {
      if (closed) return;
      closed = true;
      await new Promise((accept, reject) => {
        server.close(error => error ? reject(error) : accept());
        server.closeIdleConnections();
      });
      env.close();
    },
  };
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const site = await createPortableServer({
    dataDir: process.env.DATA_DIR || join(ROOT, 'portable', 'data'),
    adminPassword: process.env.ADMIN_PASSWORD,
    host: process.env.HOST || '0.0.0.0',
    port: Number(process.env.PORT || 8080),
    publicOrigin: process.env.PUBLIC_ORIGIN || undefined,
  });
  console.log('小窝已启动：' + site.address);
  console.log('公开浏览已开启；主人请访问 /owner-login 输入管理密码。');
  process.once('SIGINT', async () => { await site.close(); process.exit(0); });
  process.once('SIGTERM', async () => { await site.close(); process.exit(0); });
}

