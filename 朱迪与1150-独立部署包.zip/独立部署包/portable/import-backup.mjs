import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {createLocalEnv} from '../scripts/local-env.mjs';
import {handleApi} from '../worker/api.js';
const ROOT=resolve(import.meta.dirname,'..');
export async function importBackupFile(backupPath,{dataDir=join(ROOT,'portable/data'),once=false}={}){
 const storage=resolve(dataDir);await mkdir(storage,{recursive:true});
 const markerPath=join(storage,'initial-import.json');
 let marker;try{marker=JSON.parse(await readFile(markerPath,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
 if(once&&marker?.phase==='complete')return {skipped:true,photos:marker.photos};
 const source=await readFile(resolve(backupPath),'utf8');
 const hash=createHash('sha256').update(source).digest('hex');
 const backup=JSON.parse(source);
 if(backup.version!==1||!Array.isArray(backup.photos)||!backup.profile)throw new Error('请选择有效的回忆备份。');
 if(marker?.phase==='in-progress'&&marker.hash!==hash)throw new Error('上次初始导入尚未结束，请使用同一份备份继续。');
 const env=await createLocalEnv({databasePath:join(storage,'album.sqlite'),objectPath:join(storage,'objects'),ownerEmail:'owner@portable.invalid'});
 const origin='http://initial-import.local';
 const call=async(path,method='GET',body)=>{
  const headers={'Origin':origin,'Content-Type':'application/json','oai-authenticated-user-id':'local-import-owner','oai-authenticated-user-email':env.OWNER_EMAIL};
  const response=await handleApi(new Request(origin+path,{method,headers,...(body?{body:JSON.stringify(body)}:{})}),env);
  const data=await response.json();if(!response.ok)throw new Error(data.error||'初始回忆导入失败');return data;
 };
 try{
  const album=await call('/api/photos');
  let diary=await call('/api/diary');
  if(once&&!marker&&(album.count>0||diary.diary!==null))return {skipped:true,photos:album.count,reason:'existing-data'};
  if(once)await writeFile(markerPath,JSON.stringify({phase:'in-progress',hash}));
  for(const photo of backup.photos)await call('/api/photos','POST',{...photo,city:photo.city||''});
  diary=await call('/api/diary');
  const {version,exportedAt,photos,...content}=backup;
  await call('/api/diary','PUT',{diary:content,revision:diary.revision});
  if(once)await writeFile(markerPath,JSON.stringify({phase:'complete',hash,photos:photos.length}));
  return {imported:true,photos:photos.length};
 }finally{env.close();}
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
 const filename=process.argv[2];if(!filename)throw new Error('用法：node portable/import-backup.mjs 回忆备份.json [--once]');
 const result=await importBackupFile(filename,{dataDir:process.env.DATA_DIR||undefined,once:process.argv.includes('--once')});
 console.log(JSON.stringify(result));
}

